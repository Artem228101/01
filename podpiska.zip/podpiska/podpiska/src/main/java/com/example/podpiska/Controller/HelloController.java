package com.example.podpiska.Controller;

import com.example.podpiska.database.DatabaseHandler;
import com.example.podpiska.database.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class HelloController {
        @FXML private Button buttonAuthorization;
        @FXML private Button buttonRegistration;
        @FXML private Label errorLabel;
        @FXML private TextField loginTextField;
        @FXML private TextField passwordTextField;
        private final DatabaseHandler databaseHandler = new DatabaseHandler();
        @FXML
        void initialize() {
            buttonAuthorization.setOnAction(actionEvent -> {
                try {loginUser();}
                catch (SQLException | ClassNotFoundException | DatabaseHandler.SQLException throwables) {throwables.printStackTrace();}
            });
            buttonRegistration.setOnAction(actionEvent -> openOtherWindow("resources/com/example/podpiska/registration.fxml"));
        }

        private void loginUser() throws SQLException, ClassNotFoundException, DatabaseHandler.SQLException {
            String username = loginTextField.getText().trim();
            String password = passwordTextField.getText().trim();
            try {
                if (databaseHandler.signInUser(username, password)) {
                    boolean role = databaseHandler.returnRole(username);
                    User.setUsername(username);
                    User.setRole(role);
                    openOtherWindow("resources/com/example/podpiska/desktop.fxml");
                } else {
                    errorLabel.setText("Логин или пароль неверен");
                }
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
            }
        }

        private void openOtherWindow(String path){
            buttonAuthorization.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource(path));
            try {loader.load();}
            catch (IOException ioException) {ioException.printStackTrace();}
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        }

    private class SQLException extends Throwable {
    }
}